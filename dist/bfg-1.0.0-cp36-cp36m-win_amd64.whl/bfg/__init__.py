from pkg_resources import get_distribution

name = "bfg"
__version__ = get_distribution('bfg').version
FONT_BOLD = 'data/DINBold.ttf'
