Slicer
======
Overview
--------
slicer is a mesh-slicing program that outputs bitmap images for use in a 3D-printer.

Installation
------------
To install, 

Example
-------


Compilation
-----------
To compile Cython code:

python setup.py build_ext --inplace

On MacOSX, type in:

export MACOSX_DEPLOYMENT_TARGET=10.9

Packaging
---------
python setup.py sdist bdist_wheel